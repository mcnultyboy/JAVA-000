package com.yb.MultiDataSource1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiDataSource1Application {

	public static void main(String[] args) {
		SpringApplication.run(MultiDataSource1Application.class, args);
	}

}
