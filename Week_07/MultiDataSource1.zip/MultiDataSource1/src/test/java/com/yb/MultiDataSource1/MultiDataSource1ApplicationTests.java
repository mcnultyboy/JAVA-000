package com.yb.MultiDataSource1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDataSource1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
